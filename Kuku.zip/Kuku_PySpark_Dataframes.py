# Databricks notebook source
# MAGIC %md Verifying files import being successful

# COMMAND ----------

dbutils.fs.ls("dbfs:/FileStore/tables/")


# COMMAND ----------

# MAGIC %md Copy to root tmp folder to extract/uncompress files

# COMMAND ----------

dbutils.fs.cp("dbfs:/FileStore/tables/clinicaltrial_2019_csv.gz", "file:/tmp")
dbutils.fs.cp("dbfs:/FileStore/tables/clinicaltrial_2020_csv.gz", "file:/tmp")
dbutils.fs.cp("dbfs:/FileStore/tables/clinicaltrial_2021_csv.gz", "file:/tmp")


# COMMAND ----------

# MAGIC %md  checking copying was successful

# COMMAND ----------

# MAGIC %sh 
# MAGIC ls /tmp

# COMMAND ----------

# MAGIC %md uncompressing files and deleting source file with gunzip cmd w/ shell script

# COMMAND ----------

# MAGIC %sh
# MAGIC gunzip -d /tmp/clinicaltrial_2019_csv.gz
# MAGIC gunzip -d /tmp/clinicaltrial_2020_csv.gz
# MAGIC gunzip -d /tmp/clinicaltrial_2021_csv.gz
# MAGIC ls /tmp

# COMMAND ----------

# MAGIC %md copying files back to the dbfs tables folder, also renaming file name to .csv file format 

# COMMAND ----------

dbutils.fs.cp("file:/tmp/clinicaltrial_2019_csv","dbfs:/FileStore/tables/clinicaltrial_2019.csv")
dbutils.fs.cp("file:/tmp/clinicaltrial_2020_csv","dbfs:/FileStore/tables/clinicaltrial_2020.csv")
dbutils.fs.cp("file:/tmp/clinicaltrial_2021_csv","dbfs:/FileStore/tables/clinicaltrial_2021.csv")

# COMMAND ----------

dbutils.fs.ls("FileStore/tables")

# COMMAND ----------

# MAGIC %md cleaning residual files

# COMMAND ----------

dbutils.fs.rm("FileStore/tables/clinicaltrial_2019_csv.gz")
dbutils.fs.rm("FileStore/tables/clinicaltrial_2020_csv.gz")
dbutils.fs.rm("FileStore/tables/clinicaltrial_2021_csv.gz")
dbutils.fs.ls("FileStore/tables")


# COMMAND ----------

# MAGIC %sh
# MAGIC rm /tmp/clinicaltrial_2019_csv
# MAGIC rm /tmp/clinicaltrial_2020_csv
# MAGIC rm /tmp/clinicaltrial_2021_csv
# MAGIC ls /tmp

# COMMAND ----------

# MAGIC %md initiating spark session

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import Window
import pandas as pd
import matplotlib.pyplot as plt

# COMMAND ----------

spark=SparkSession.builder.getOrCreate()
f = False

# COMMAND ----------

# MAGIC %md  Dataframes creation using Spark inferschema

# COMMAND ----------

ph_df = spark.read.options(header='True', inferSchema='True', delimiter='|') \
  .csv("dbfs:/FileStore/tables/clinicaltrial_2019.csv")
ph_df2 = spark.read.options(header='True', inferSchema='True', delimiter='|') \
  .csv("dbfs:/FileStore/tables/clinicaltrial_2020.csv")
ph_df3 = spark.read.options(header='True', inferSchema='True', delimiter='|') \
  .csv("dbfs:/FileStore/tables/clinicaltrial_2021.csv")
display(ph_df)
display(ph_df2)
display(ph_df3)


# COMMAND ----------

# MAGIC %md # Task 1: Distinct number of Studies in all three dataset

# COMMAND ----------

Uniq_df=ph_df.select(countDistinct("Id"))
Uniq_df2=ph_df2.select(countDistinct("Id"))
Uniq_df3=ph_df3.select(countDistinct("Id"))

Uniq_df.show()
Uniq_df2.show()
Uniq_df3.show()

# COMMAND ----------

# MAGIC %md # Task 2: Count of All Types 

# COMMAND ----------

sort_df = ph_df.groupBy("Type").count().orderBy(desc("count")).show()
sort_df2 = ph_df2.groupBy("Type").count().orderBy(desc("count")).show()

# COMMAND ----------

sort_df3 = ph_df3.groupBy("Type").count().orderBy(desc("count")).show()

# COMMAND ----------

# MAGIC %md # Task 3: Top 5 Conditions count

# COMMAND ----------

#2019
conds= ph_df.withColumn("Conditions", split(col("Conditions"), "\\,"))
import pyspark.sql.functions as F
conds_count = conds.withColumn("Conditions", F.explode("Conditions")).groupBy("Conditions").count().orderBy(F.desc("count")).show(5)
display(conds_count)

# COMMAND ----------

#2020
conds2= ph_df2.withColumn("Conditions", split(col("Conditions"), "\\,"))
import pyspark.sql.functions as F
conds2_count = conds2.withColumn("Conditions", F.explode("Conditions")).groupBy("Conditions").count().orderBy(F.desc("count")).show(5)
display(conds2_count)

# COMMAND ----------

#2021
conds3= ph_df3.withColumn("Conditions", split(col("Conditions"), "\\,"))
import pyspark.sql.functions as F
conds3_count = conds3.withColumn("Conditions", F.explode("Conditions")).groupBy("Conditions").count().orderBy(F.desc("count")).show(5)
display(conds3_count)

# COMMAND ----------

# MAGIC %md # Task 4: Finding Top 5 most Frequent roots

# COMMAND ----------

ph_df4 = spark.read.options(header='True', inferSchema='True') \
  .csv("dbfs:/FileStore/tables/mesh.csv")
df4 =ph_df4.select('term', 'tree', substring('tree', 1,3).alias('root')).drop('tree') 
#df4 = df4.dropDuplicates(['term','root'])
display(df4)

# COMMAND ----------

#2019
import pyspark.sql.functions as F

expld= ph_df.withColumn("Conditions", split(col("Conditions"), "\\,"))
ans = expld.withColumn("Conditions", F.explode("Conditions"))
anti_df5= ans.join(df4, (ans.Conditions == df4.term) ,"left").select(df4.root, ans.Conditions)
anti_df5_count = anti_df5.groupBy('root').count().sort('count',ascending=False).filter("root IS NOT null").take(10)
display(anti_df5_count)

# COMMAND ----------

#2020
import pyspark.sql.functions as F

expld2 = ph_df2.withColumn("Conditions", split(col("Conditions"), "\\,"))
ans2 = expld2.withColumn("Conditions", F.explode("Conditions"))
anti_df5= ans2.join(df4, (ans2.Conditions == df4.term) ,"left").select(df4.root, ans2.Conditions)
anti_df5_count = anti_df5.groupBy('root').count().sort('count',ascending=False).filter("root IS NOT null").take(10)
display(anti_df5_count)

# COMMAND ----------

#2021
import pyspark.sql.functions as F

expld3 = ph_df3.withColumn("Conditions", split(col("Conditions"), "\\,"))
ans3 = expld3.withColumn("Conditions", F.explode("Conditions"))
anti_df5= ans3.join(df4, (ans3.Conditions == df4.term) ,"left").select(df4.root, ans3.Conditions)
anti_df5_count = anti_df5.groupBy('root').count().sort('count',ascending=False).filter("root IS NOT null").take(10)
display(anti_df5_count)

# COMMAND ----------

# MAGIC %md # Task 5: Top 10 Sponsor frequency count without pharma companies 

# COMMAND ----------

# MAGIC %md importing pharma.csv to get the pharma company list 

# COMMAND ----------

new_df5 = spark.read.options(header='True', inferSchema='True', delimiter=',') \
  .csv("dbfs:/FileStore/tables/pharma.csv")
display(new_df5)


# COMMAND ----------

#2019
anti2_df= ph_df.join(new_df5, (ph_df.Sponsor == new_df5.Parent_Company) ,"anti").select(ph_df.Id, ph_df.Sponsor)
anti2_df2_count = anti2_df.groupBy('Sponsor').count().sort('count',ascending=False).take(10)
display(anti2_df2_count)

# COMMAND ----------

#2020
anti_df= ph_df2.join(new_df5, (ph_df2.Sponsor == new_df5.Parent_Company) ,"anti").select(ph_df2.Id, ph_df2.Sponsor)
anti_df2_count = anti_df.groupBy('Sponsor').count().sort('count',ascending=False).take(10)
display(anti_df2_count)


# COMMAND ----------

#2021
anti3_df= ph_df3.join(new_df5, (ph_df3.Sponsor == new_df5.Parent_Company) ,"anti").select(ph_df3.Id, ph_df3.Sponsor)
anti3_df2_count = anti3_df.groupBy('Sponsor').count().sort('count',ascending=False).take(10)
display(anti3_df2_count)

# COMMAND ----------

# MAGIC %md # Task 6: Plotting number of completed studies each month for the given year

# COMMAND ----------

#2019
ph_df_2019 = ph_df.where(("Completion like '%%%%2019'")) \
                .filter("Status = 'Completed'")
ph_df_count = ph_df_2019.select(substring("Completion",1,3).alias("month")).groupBy("month").count().orderBy("month").filter("month IS NOT NULL")
ph_df_count.show()

# COMMAND ----------

#2020
ph_df2_2020 = ph_df2.where(("Completion like '%%%%2020'")) \
                .filter("Status = 'Completed'")
ph_df2_count = ph_df2_2020.select(substring("Completion",1,3).alias("month")).groupBy("month").count().orderBy("month").filter("month IS NOT NULL")
ph_df2_count.show()

# COMMAND ----------

#2021
ph_df3_2021 = ph_df3.where(("Completion like '%%%%2021'")) \
                .filter("Status = 'Completed'")
ph_df3_count = ph_df3_2021.select(substring("Completion",1,3).alias("month")).groupBy("month").count().orderBy("month").filter("month IS NOT NULL")
ph_df3_count.show()

# COMMAND ----------

# MAGIC %md Visualizing using python pandas

# COMMAND ----------

#2019
ph_count= ph_df_count.toPandas()
ph_count.plot.bar(x='month', y='count')
#2020
ph2_count= ph_df2_count.toPandas()
ph2_count.plot.bar(x='month', y='count')
#2021
ph3_count= ph_df3_count.toPandas()
ph3_count.plot.bar(x='month', y='count')
