-- Databricks notebook source
-- MAGIC %md verifying dataset 

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.fs.ls("dbfs:/FileStore/tables/")

-- COMMAND ----------

DROP Table if exists clinicaltrial_2021;
create table if not exists clinicaltrial_2021
(
Id string, 
Sponsor string, 
Status string, 
`Start` string,
Completion string,
Type string, 
Submission string, 
Conditions string, 
Interventions string
)
USING csv OPTIONS ('escape' '\"', 'header' 'true', 'delimiter' '|')
LOCATION '/FileStore/tables/clinicaltrial_2021.csv';

-- COMMAND ----------

select * from clinicaltrial_2021;

-- COMMAND ----------

DROP Table if exists clinicaltrial_2020;
create table if not exists clinicaltrial_2020
(
Id string, 
Sponsor string, 
Status string, 
`Start` string,
Completion string,
Type string, 
Submission string, 
Conditions string, 
Interventions string
)
USING csv OPTIONS ('escape' '\"', 'header' 'true', 'delimiter' '|')
LOCATION '/FileStore/tables/clinicaltrial_2020.csv';

-- COMMAND ----------

DROP Table if exists clinicaltrial_2019;
create table if not exists clinicaltrial_2019
(
Id string, 
Sponsor string, 
Status string, 
`Start` string,
Completion string,
Type string, 
Submission string, 
Conditions string, 
Interventions string
)
USING csv OPTIONS ('escape' '\"', 'header' 'true', 'delimiter' '|')
LOCATION '/FileStore/tables/clinicaltrial_2019.csv';

-- COMMAND ----------

select * from clinicaltrial_2019;

-- COMMAND ----------

-- MAGIC %md # Task 1: Distinct number of Studies in all three dataset

-- COMMAND ----------

#2021
SELECT COUNT(DISTINCT Id) FROM clinicaltrial_2021;

-- COMMAND ----------

#2020
SELECT COUNT(DISTINCT Id) FROM clinicaltrial_2020;

-- COMMAND ----------

#2019
SELECT COUNT(DISTINCT Id) FROM clinicaltrial_2019;

-- COMMAND ----------

-- DBTITLE 0,Hi
-- MAGIC %md # Task 2: Count of All Types 

-- COMMAND ----------

select Type, count(*) Frequency from clinicaltrial_2021 group by Type order by Frequency desc;

-- COMMAND ----------

select Type, count(*) Frequency from clinicaltrial_2020 group by Type order by Frequency desc;

-- COMMAND ----------

select Type, count(*) Frequency from clinicaltrial_2019 group by Type order by Frequency desc;


-- COMMAND ----------

-- MAGIC %md # Task 3: Top 5 conditions count 

-- COMMAND ----------

SELECT new_conditions, count(new_conditions) as count
FROM clinicaltrial_2019 lateral view explode(split(Conditions,',')) Conditions AS new_conditions 
where new_conditions is not null
 and  new_conditions != ''
group by  new_conditions
order by  count desc limit 5

-- COMMAND ----------

SELECT new_conditions, count(new_conditions) as count
FROM clinicaltrial_2020 lateral view explode(split(Conditions,',')) Conditions AS new_conditions 
where new_conditions is not null
 and  new_conditions != ''
group by  new_conditions
order by  count desc limit 5

-- COMMAND ----------

SELECT new_conditions, count(new_conditions) as count
FROM clinicaltrial_2021 lateral view explode(split(Conditions,',')) Conditions AS new_conditions 
where new_conditions is not null
 and  new_conditions != ''
group by  new_conditions
order by  count desc limit 5

-- COMMAND ----------

-- MAGIC %md # Task 4: Finding Top 5 most Frequent roots

-- COMMAND ----------

DROP Table if exists mesh;
create table if not exists mesh
(
term String,
tree string
)
USING csv OPTIONS ('escape' '\"', 'header' 'true')
LOCATION '/FileStore/tables/mesh.csv';

-- COMMAND ----------

create table new_2019 as 
SELECT new_conditions
FROM clinicaltrial_2019 lateral view explode(split(Conditions,',')) Conditions AS new_conditions; 
create table new_2020 as 
SELECT new_conditions
FROM clinicaltrial_2020 lateral view explode(split(Conditions,',')) Conditions AS new_conditions; 
create table new_2021 as 
SELECT new_conditions
FROM clinicaltrial_2021 lateral view explode(split(Conditions,',')) Conditions AS new_conditions; 

-- COMMAND ----------

CREATE TABLE 2019_mesh AS
SELECT * 
FROM mesh 
right outer JOIN new_2019
ON mesh.term = new_2019.new_conditions;

SELECT LEFT(tree,3) AS root, count(*) as Count
FROM 2019_mesh
GROUP BY root
ORDER BY Count DESC
LIMIT 5;

-- COMMAND ----------

CREATE TABLE 2020_mesh AS
SELECT * 
FROM mesh 
right outer JOIN new_2020
ON mesh.term = new_2020.new_conditions;

SELECT LEFT(tree,3) AS root, count(*) as Count
FROM 2020_mesh
GROUP BY root
ORDER BY Count DESC
LIMIT 5;

-- COMMAND ----------

CREATE TABLE 2021_mesh AS
SELECT * 
FROM mesh 
right outer JOIN new_2021
ON mesh.term = new_2021.new_conditions;

SELECT LEFT(tree,3) AS root, count(*) as Count
FROM 2021_mesh
GROUP BY root
ORDER BY Count DESC
LIMIT 5;

-- COMMAND ----------

-- MAGIC %md # Task 5: Top 10 Sponsor frequency count without pharma companies 

-- COMMAND ----------

DROP Table if exists pharma;
create table if not exists pharma
(
Parent_Company String
)
USING csv OPTIONS ('escape' '\"', 'header' 'true', 'delimiter' ',')
LOCATION '/FileStore/tables/pharma.csv'; 

-- COMMAND ----------

select * from pharma;

-- COMMAND ----------

SELECT clinicaltrial_2019.Sponsor as Sponsor, Count(clinicaltrial_2019.Sponsor) as count
FROM clinicaltrial_2019
LEFT ANTI JOIN pharma
ON clinicaltrial_2019.Sponsor = pharma.Parent_Company
group by  clinicaltrial_2019.Sponsor
order by  count desc limit 10

-- COMMAND ----------

SELECT clinicaltrial_2020.Sponsor as Sponsor, Count(clinicaltrial_2020.Sponsor) as count
FROM clinicaltrial_2020
LEFT ANTI JOIN pharma
ON clinicaltrial_2020.Sponsor = pharma.Parent_Company
group by  clinicaltrial_2020.Sponsor
order by  count desc limit 10

-- COMMAND ----------

SELECT clinicaltrial_2021.Sponsor as Sponsor, Count(clinicaltrial_2021.Sponsor) as count
FROM clinicaltrial_2021
LEFT ANTI JOIN pharma
ON clinicaltrial_2021.Sponsor = pharma.Parent_Company
group by  clinicaltrial_2021.Sponsor
order by  count desc limit 10

-- COMMAND ----------

-- MAGIC %md # Task 6: Plotting number of completed studies each month for the given year

-- COMMAND ----------

SELECT substr(Completion,1,3) as Completed, count(substr(Completion,1,3)) as count
FROM clinicaltrial_2019 
WHERE Completion LIKE '%%%%2019' AND status='Completed'
group by  substr(Completion,1,3)
order by  count desc 

-- COMMAND ----------

SELECT substr(Completion,1,3) as Comp, count(substr(Completion,1,3)) as count
FROM clinicaltrial_2020 
WHERE Completion LIKE '%%%%2020' AND status='Completed'
group by  substr(Completion,1,3)
order by  count desc 

-- COMMAND ----------

SELECT substr(Completion,1,3) as Comp, count(substr(Completion,1,3)) as count
FROM clinicaltrial_2021 
WHERE Completion LIKE '%%%%2021' AND status='Completed'
group by  substr(Completion,1,3)
order by  count desc 
